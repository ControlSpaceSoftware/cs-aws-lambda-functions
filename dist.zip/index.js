'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _apiGatewayProxyWrapper = require('./apiGatewayProxyWrapper');

Object.defineProperty(exports, 'apiGatewayProxyWrapper', {
  enumerable: true,
  get: function get() {
    return _interopRequireDefault(_apiGatewayProxyWrapper).default;
  }
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }